from django.contrib import admin
from django.urls import path, include
from todos.views import (
    home_view,
    todo_list_view,
    create_todo,
    update_todo,
    delete_todo,
    register_user,
    login_user,
)

# urlpatterns = [
#     # Redirect to login/register page for default URL
#     path('', login_user, name='login_redirect'),
#     path('admin/', admin.site.urls),
#     path('login/', login_user, name='login'),
#     path('register/', register_user, name='register'),
#     path('todos/', todo_list_view, name='todo_list'),
#     path('todos/create/', create_todo, name='create_todo'),
#     path('todos/<int:pk>/', update_todo, name='update_todo'),
#     path('todos/<int:pk>/delete/', delete_todo, name='delete_todo'),
#     # Remove API documentation path
# ]

# todo_project/urls.py

# todo_project/urls.py

from django.contrib import admin
from django.urls import path, include
from todos import views as todos_views

urlpatterns = [
    # Admin site URL
    path('admin/', admin.site.urls),

    # Include todos app URLs
    path('', include('todos.urls')),

    # Login and register URLs
    path('login/', todos_views.login_user, name='login'),
    path('register/', todos_views.register_user, name='register'),

    # Handle CSRF failures
    path('csrf_failure/', todos_views.csrf_failure, name='csrf_failure'),
]

