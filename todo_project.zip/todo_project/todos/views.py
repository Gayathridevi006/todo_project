# views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegistrationForm, TodoForm
from .models import Todo

def home_view(request):
    return render(request, 'home.html')

def todo_list_view(request):
    todos = Todo.objects.all()
    return render(request, 'todo_list.html', {'todos': todos})

def register_user(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})

def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('todo_list')  # Redirect to todo_list after login
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')

@login_required
def list_tasks(request):
    tasks = Todo.objects.all()
    return render(request, 'todo_list.html', {'tasks': tasks})

@login_required
def create_task(request):
    if request.method == 'POST':
        form = TodoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('list_tasks')
    else:
        form = TodoForm()
    return render(request, 'create_task.html', {'form': form})
       
@login_required
def retrieve_task(request, id):
    task = Todo.objects.get(id=id)
    return render(request, 'task_detail.html', {'task': task})

@login_required
def update_task(request, id):
    task = Todo.objects.get(id=id)
    if request.method == 'POST':
        form = TodoForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('list_tasks')
    else:
        form = TodoForm(instance=task)
    return render(request, 'update_task.html', {'form': form, 'task': task})

@login_required
def delete_task(request, id):
    task = Todo.objects.get(id=id)
    if request.method == 'POST':
        task.delete()
        return redirect('list_tasks')
    return render(request, 'delete_task.html', {'task': task})

@login_required
def todo_list_view(request):
    todos = Todo.objects.all()
    return render(request, 'todo_list.html', {'todos': todos})

@login_required
@login_required
def create_todo(request):
    if request.method == 'POST':
        form = TodoForm(request.POST)
        if form.is_valid():
            todo = form.save(commit=False)
            todo.user = request.user  # Assign the current user to the todo
            todo.save()
            return redirect('todo_list')
    else:
        form = TodoForm()
    return render(request, 'todo_form.html', {'form': form})


@login_required
def update_todo(request, pk):
    todo = get_object_or_404(Todo, pk=pk)
    if request.method == 'POST':
        form = TodoForm(request.POST, instance=todo)
        if form.is_valid():
            todo = form.save(commit=False)
            todo.user = request.user  # Assign the current user to the todo
            todo.save()
            return redirect('todo_list')
    else:
        form = TodoForm(instance=todo)
    return render(request, 'todo_form.html', {'form': form})


@login_required
def delete_todo(request, pk):
    todo = Todo.objects.get(pk=pk)
    if request.method == 'POST':
        todo.delete()
        return redirect('todo_list')
    return render(request, 'todo_confirm_delete.html', {'todo': todo})

def csrf_failure(request, reason=""):
    # Handle CSRF failure here
    context = {
        'reason': reason,
    }
    return render(request, 'csrf_failure.html', context)

