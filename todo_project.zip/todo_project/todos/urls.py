# todos/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('todos/', views.todo_list_view, name='todo_list'),
    path('history/', views.todo_list_view, name='task_history'),
    path('todos/<int:pk>/', views.retrieve_task, name='retrieve_task'),
    path('create/', views.create_todo, name='create_todo'),
    path('update/<int:pk>/', views.update_todo, name='update_todo'),  # Ensure this line is present
    path('delete/<int:pk>/', views.delete_todo, name='delete_todo'),
    path('register/', views.register_user, name='register'),
    path('login/', views.login_user, name='login'),
    path('create/', views.create_todo, name='create_todo'),

]

