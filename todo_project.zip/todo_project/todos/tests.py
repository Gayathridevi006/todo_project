from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from django.contrib.auth.models import User
from .models import Todo
from .serializers import TodoSerializer
from datetime import datetime, timedelta

class TodoAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(username='testuser', password='testpassword')
        self.client.login(username='testuser', password='testpassword')
        self.todo1 = Todo.objects.create(user=self.user, name='Task 1', description='Description 1',
                                         deadline=datetime.now() + timedelta(days=1))
        self.todo2 = Todo.objects.create(user=self.user, name='Task 2', description='Description 2',
                                         deadline=datetime.now() + timedelta(days=2))

    def test_create_todo(self):
        url = '/api/todos/'
        data = {'name': 'New Task', 'description': 'New Description', 'deadline': datetime.now() + timedelta(days=3)}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Todo.objects.count(), 3)
        self.assertEqual(Todo.objects.get(name='New Task').description, 'New Description')

    def test_update_todo(self):
        url = f'/api/todos/{self.todo1.id}/'
        data = {'name': 'Updated Task', 'description': 'Updated Description', 'deadline': self.todo1.deadline}
        response = self.client.put(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(Todo.objects.get(id=self.todo1.id).name, 'Updated Task')

    def test_delete_todo(self):
        url = f'/api/todos/{self.todo2.id}/delete/'
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Todo.objects.filter(id=self.todo2.id).exists())

    def test_register_user(self):
        url = '/api/register/'
        data = {'username': 'newuser', 'password': 'newpassword'}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(User.objects.filter(username='newuser').exists())

    def test_login_user(self):
        url = '/api/login/'
        data = {'username': 'testuser', 'password': 'testpassword'}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

