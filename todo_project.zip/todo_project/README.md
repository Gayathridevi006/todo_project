
python manage.py migrate
python manage.py runserver

docker build -t my-django-app .
docker run -p 8000:8000 my-django-app


## celery -->
